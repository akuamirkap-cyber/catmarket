// ---------------------------------------------------------------
//  Beach Playground & Resort (Zone 3 & 4):
//  1. Surfing cats carving across ocean waves with dynamic surf crests & spray
//  2. Grand 2X Sandcastle with cat scooping sand & patting towers
//  3. Running Kite Flying cats actively jogging back and forth with swooping kites
//  4. Roaming kittens & kid cats playing tag, chasing beach balls & crabs
//  5. 2X Giant Beach Volleyball court with 4 jumping cats & 2.4X beach ball
//  6. Sunbathing cats truly LYING DOWN (rebahan/tiduran santai) on towels
//  7. Sun from the LEFT: all shadows cast to the RIGHT, umbrellas angled to the left!
// ---------------------------------------------------------------
import { drawCat, makeCat, CUSTOMER_PALS, type Cat, type Pal } from './cat';

const PI = Math.PI;
const PI2 = Math.PI * 2;
const OUT = '#58244a';

function ell(c: CanvasRenderingContext2D, x: number, y: number, rx: number, ry: number, fill: string, stroke?: string, lw = 1.6) {
  c.beginPath();
  c.ellipse(x, y, rx, ry, 0, 0, PI2);
  c.fillStyle = fill;
  c.fill();
  if (stroke) { c.lineWidth = lw; c.strokeStyle = stroke; c.stroke(); }
}

// ---------------------------------------------------------------
//  1. MAIN PASIR: 2X GRAND SANDCASTLE & ANIMATED SCOOPING CAT
// ---------------------------------------------------------------
export function drawSandPlayCat(ctx: CanvasRenderingContext2D, x: number, y: number, t: number, pal: Pal) {
  ctx.save();
  ctx.translate(x, y);

  // Sun from the LEFT: shadow casts to the RIGHT (+dx, +dy)
  ctx.globalAlpha = 0.22;
  ctx.fillStyle = '#3a2a10';
  ctx.beginPath(); ctx.ellipse(28, 14, 76, 20, 0.08, 0, PI2); ctx.fill();
  ctx.globalAlpha = 1;

  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';

  // Sand Moat around the castle
  ctx.strokeStyle = 'rgba(180,135,70,.4)';
  ctx.lineWidth = 6;
  ctx.beginPath(); ctx.ellipse(22, 6, 82, 32, 0, 0, PI2); ctx.stroke();

  // 2X GRAND SANDCASTLE
  const cx = 22, cy = 0;

  // Outer Curtain Walls
  ctx.beginPath();
  ctx.moveTo(cx - 55, cy + 14);
  ctx.lineTo(cx - 48, cy - 24);
  ctx.lineTo(cx + 48, cy - 24);
  ctx.lineTo(cx + 55, cy + 14);
  ctx.closePath();
  ctx.fillStyle = '#e5be74'; ctx.fill();
  ctx.lineWidth = 3.2; ctx.strokeStyle = OUT; ctx.stroke();

  // Wall crenellations (crenels)
  for (let k = -42; k <= 42; k += 14) {
    ctx.fillStyle = '#edd18e';
    ctx.fillRect(cx + k - 4, cy - 30, 8, 7);
    ctx.strokeRect(cx + k - 4, cy - 30, 8, 7);
  }

  // 4 Corner Towers
  for (const sx of [-46, 46]) {
    // Tower cylinder
    ctx.beginPath();
    ctx.roundRect(cx + sx - 13, cy - 42, 26, 38, 4);
    ctx.fillStyle = sx < 0 ? '#f0d28e' : '#deb66c'; ctx.fill(); // Left lit, right shaded
    ctx.lineWidth = 3; ctx.strokeStyle = OUT; ctx.stroke();

    // Tower battlement
    for (const bx of [-9, -1, 7]) {
      ctx.fillRect(cx + sx + bx - 2, cy - 49, 5, 8);
      ctx.strokeRect(cx + sx + bx - 2, cy - 49, 5, 8);
    }

    // Conical Tower Roof with Gold Trim
    ctx.beginPath();
    ctx.moveTo(cx + sx - 15, cy - 47);
    ctx.lineTo(cx + sx, cy - 68);
    ctx.lineTo(cx + sx + 15, cy - 47);
    ctx.closePath();
    ctx.fillStyle = '#ffd24a'; ctx.fill();
    ctx.lineWidth = 2.6; ctx.strokeStyle = OUT; ctx.stroke();

    // Little fluttering flag (blown right by breeze)
    const fw = Math.sin(t * 7 + sx) * 2.5;
    ctx.strokeStyle = '#5a3a14'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(cx + sx, cy - 68); ctx.lineTo(cx + sx, cy - 82); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(cx + sx, cy - 82); ctx.lineTo(cx + sx + 14 + fw, cy - 76); ctx.lineTo(cx + sx, cy - 70); ctx.closePath();
    ctx.fillStyle = sx < 0 ? '#ff4d6a' : '#4ea8e8'; ctx.fill();
    ctx.lineWidth = 1.6; ctx.strokeStyle = OUT; ctx.stroke();
  }

  // Grand Central Keep Tower (Taller, Majestic!)
  ctx.beginPath();
  ctx.roundRect(cx - 20, cy - 58, 40, 42, 6);
  ctx.fillStyle = '#f4d896'; ctx.fill();
  ctx.lineWidth = 3.2; ctx.strokeStyle = OUT; ctx.stroke();

  // Central Keep battlements
  for (const bx of [-14, -6, 2, 10]) {
    ctx.fillRect(cx + bx, cy - 66, 6, 9);
    ctx.strokeRect(cx + bx, cy - 66, 6, 9);
  }

  // Central High Flagpole
  const cfw = Math.sin(t * 9) * 3;
  ctx.strokeStyle = '#5a3a14'; ctx.lineWidth = 2.4;
  ctx.beginPath(); ctx.moveTo(cx, cy - 66); ctx.lineTo(cx, cy - 90); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(cx, cy - 90); ctx.lineTo(cx + 20 + cfw, cy - 81); ctx.lineTo(cx, cy - 72); ctx.closePath();
  ctx.fillStyle = '#ff3b50'; ctx.fill();
  ctx.lineWidth = 2; ctx.strokeStyle = OUT; ctx.stroke();
  // Star on flag
  ctx.fillStyle = '#ffe45c';
  ctx.beginPath(); ctx.arc(cx + 7 + cfw * 0.4, cy - 81, 2.5, 0, PI2); ctx.fill();

  // Arched Portcullis Gateway
  ctx.beginPath(); ctx.arc(cx, cy + 14, 11, PI, 0); ctx.fillStyle = '#4a2c14'; ctx.fill();
  ctx.lineWidth = 2.4; ctx.strokeStyle = OUT; ctx.stroke();

  // Wooden drawbridge planks
  ctx.fillStyle = '#a86c38';
  ctx.fillRect(cx - 9, cy + 12, 18, 5);

  // Toy Red Bucket on the left
  ctx.beginPath();
  ctx.moveTo(-42, 4); ctx.lineTo(-28, 4); ctx.lineTo(-31, 22); ctx.lineTo(-39, 22); ctx.closePath();
  ctx.fillStyle = '#ff5a7a'; ctx.fill();
  ctx.lineWidth = 2.4; ctx.strokeStyle = OUT; ctx.stroke();
  ctx.strokeStyle = '#ffd24a'; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(-42, 4); ctx.quadraticCurveTo(-35, -7, -28, 4); ctx.stroke();

  // Cat Animation: Scooping sand & patting
  // Phase 0..1: scoop down, lift spade, pat castle!
  const cycle = (t * 2) % 1;
  const scoopY = Math.sin(cycle * PI2) * 5;
  const armRot = Math.sin(cycle * PI2) * 0.4;

  // Cat sitting happily on knees playing with spade & castle
  // Open wide sparkly cute eyes (bukan merem terus!)
  const cat = makeCat(0, 0, pal);
  cat.t = t;
  cat.happy = 0;       // wide open eyes!
  cat.exc = 0.6;
  cat.eyesOpen = true;  // mata bulat bersinar terbuka
  cat.fx = 1;
  cat.side = 1;

  ctx.save();
  ctx.translate(-24, 12 + scoopY * 0.3);
  drawCat(ctx, cat, 0.78);

  // Spade held in paw, actively scooping and shaping sand!
  ctx.save();
  ctx.translate(14, -22);
  ctx.rotate(0.3 + armRot);
  ctx.fillStyle = '#ffd24a';
  ctx.fillRect(-2, 0, 4, 18);
  ctx.beginPath(); ctx.roundRect(-6, 16, 12, 12, 3); ctx.fillStyle = '#ff9f45'; ctx.fill();
  ctx.lineWidth = 1.6; ctx.strokeStyle = OUT; ctx.stroke();
  // Flying sand grains when lifting spade
  if (cycle > 0.4 && cycle < 0.8) {
    ctx.fillStyle = '#e8c27a';
    ctx.beginPath(); ctx.arc(6, 14, 2, 0, PI2); ctx.fill();
    ctx.beginPath(); ctx.arc(10, 10, 1.6, 0, PI2); ctx.fill();
  }
  ctx.restore();

  ctx.restore();  ctx.restore();

  ctx.restore();
}

// ---------------------------------------------------------------
//  2. BERSELANCAR: DYNAMIC SURFING CATS (Carving Ocean Waves + Feet Planted)
// ---------------------------------------------------------------
export function drawSurfingCat(ctx: CanvasRenderingContext2D, baseX: number, baseY: number, t: number, pal: Pal, id: number) {
  // Leluasa berselancar: Carves back and forth across the ocean!
  // Carving sweep range ~120px
  const sweep = Math.sin(t * 0.9 + id * 2.1) * 65;
  const curX = baseX + sweep;
  const curDir = Math.cos(t * 0.9 + id * 2.1) >= 0 ? 1 : -1;

  // Ocean swell bob and pitch
  const waveH = Math.sin(t * 3.2 + curX * 0.02) * 9;
  const curY = baseY + waveH;
  const carveTilt = (curDir * 0.22) + Math.sin(t * 3.2 + curX * 0.02) * 0.14;

  ctx.save();
  ctx.translate(curX, curY);

  // 1. DYNAMIC OCEAN SURF WAVE (Ombak bergulung & berbusa di bawah papan!)
  ctx.save();
  // Big rolling wave curl
  ctx.beginPath();
  ctx.moveTo(-60 * curDir, 28);
  ctx.quadraticCurveTo(0, -6, 55 * curDir, 16);
  ctx.quadraticCurveTo(40 * curDir, 28, -60 * curDir, 28);
  ctx.closePath();
  ctx.fillStyle = 'rgba(78,212,238,.45)'; ctx.fill();

  // White cresting foam curl
  ctx.lineCap = 'round';
  ctx.strokeStyle = 'rgba(255,255,255,.92)';
  ctx.lineWidth = 4.5;
  ctx.beginPath();
  ctx.moveTo(-52 * curDir, 18);
  ctx.quadraticCurveTo(-10 * curDir, -2, 45 * curDir, 14);
  ctx.stroke();

  // Foaming water spray flying off the wave
  for (let k = 0; k < 4; k++) {
    const spX = -45 * curDir - curDir * k * 14 + Math.sin(t * 14 + k) * 4;
    const spY = 12 + Math.sin(t * 12 + k) * 6;
    ctx.fillStyle = '#ffffff';
    ctx.beginPath(); ctx.arc(spX, spY, 2.5 + (k % 2), 0, PI2); ctx.fill();
  }
  ctx.restore();

  // 2. SURFBOARD with feet FIRMLY PLANTED ON DECK
  ctx.save();
  ctx.rotate(carveTilt);
  ctx.scale(curDir, 1);

  // Surfboard shadow in water
  ctx.globalAlpha = 0.24; ctx.fillStyle = '#0a406a';
  ctx.beginPath(); ctx.ellipse(0, 16, 52, 9, 0, 0, PI2); ctx.fill();
  ctx.globalAlpha = 1;

  // Sleek Aerodynamic Surfboard
  const board = () => {
    ctx.beginPath();
    ctx.moveTo(-52, 6);
    ctx.quadraticCurveTo(0, 15, 52, 5);
    ctx.quadraticCurveTo(65, 3, 68, 1);
    ctx.quadraticCurveTo(62, -3, 50, -4);
    ctx.quadraticCurveTo(0, -11, -52, -5);
    ctx.quadraticCurveTo(-62, 1, -52, 6);
    ctx.closePath();
  };

  board();
  const bg = ctx.createLinearGradient(-52, 0, 68, 0);
  bg.addColorStop(0, '#ffd23f');
  bg.addColorStop(0.4, '#ff6b84');
  bg.addColorStop(1, '#4ea8e8');
  ctx.fillStyle = bg; ctx.fill();
  ctx.lineWidth = 3.2; ctx.strokeStyle = OUT; ctx.stroke();

  // Center racing stripe
  ctx.save();
  board(); ctx.clip();
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(-60, -2, 130, 4.5);
  ctx.restore();

  // Underwater fin (skeg)
  ctx.beginPath();
  ctx.moveTo(-42, 8); ctx.lineTo(-49, 21); ctx.lineTo(-33, 8); ctx.closePath();
  ctx.fillStyle = '#1f6596'; ctx.fill();
  ctx.lineWidth = 1.8; ctx.strokeStyle = OUT; ctx.stroke();

  // 3. CAT FIRMLY STANDING ON DECK (Napak di papan selancar!)
  // Real cat model with wide open alert, sparkly happy eyes (mata melek mantap!)
  const cat = makeCat(0, 0, pal);
  cat.t = t;
  cat.happy = 0;
  cat.exc = 0.8;
  cat.eyesOpen = true;  // mata bulat melek bercahaya!
  cat.fx = 1;
  cat.side = 1;

  ctx.save();
  ctx.translate(2, -4);
  drawCat(ctx, cat, 0.76);
  ctx.restore();  ctx.restore(); // board frame
  ctx.restore(); // world frame
}

// ---------------------------------------------------------------
//  3. MAIN LAYANGAN: KUCING AKTIF LARI-LARIAN DENGAN LAYANGAN SWOOPING
// ---------------------------------------------------------------
export function drawKiteFlyingCat(ctx: CanvasRenderingContext2D, baseX: number, groundY: number, t: number, pal: Pal, kiteType: 'fish' | 'diamond', id = 0) {
  // Cat actively jogs back and forth across the beach!
  const span = 150;
  const minX = baseX - span / 2;
  const maxX = baseX + span / 2;
  const speed = 80; // running speed
  const cycle = ((t * speed + id * 200) % (span * 2));
  const movingRight = cycle < span;
  const curX = movingRight ? minX + cycle : maxX - (cycle - span);
  const dir = movingRight ? 1 : -1;

  // Kite dynamically swoops behind the cat in the wind
  const lagDist = 85;
  const kx = curX - dir * lagDist + Math.sin(t * 2.4 + id) * 18;
  const ky = groundY - 145 + Math.cos(t * 3.2 + id) * 16;

  // Cat hand position holding spool
  const handX = curX + dir * 14;
  const handY = groundY - 36;

  // String line curving with wind
  ctx.save();
  ctx.strokeStyle = 'rgba(255,255,255,.9)';
  ctx.lineWidth = 1.8;
  ctx.beginPath();
  ctx.moveTo(handX, handY);
  ctx.quadraticCurveTo((handX + kx) / 2 - dir * 16, (handY + ky) / 2 + 15, kx, ky);
  ctx.stroke();

  // Cat running happily with wind, looking up with wide open sparkly eyes!
  const cat = makeCat(0, 0, pal);
  cat.t = t;
  cat.mv = 1;
  cat.speed = 180;
  cat.r = 0.6;
  cat.fx = dir;
  cat.side = dir;
  cat.happy = 0;       // melek!
  cat.exc = 0.8;
  cat.eyesOpen = true; // mata melek lebar menikmati layangan!
  cat.look = { x: -dir * 0.4, y: -1 }; // Looking up at kite!
  ctx.save();
  ctx.translate(curX, groundY);
  drawCat(ctx, cat, 0.74);

  // Red string spool in hand
  ctx.beginPath(); ctx.roundRect(dir * 12, -42, 7, 12, 2.5);
  ctx.fillStyle = '#ff4d5e'; ctx.fill();
  ctx.lineWidth = 1.6; ctx.strokeStyle = OUT; ctx.stroke();
  ctx.fillStyle = '#fff'; ctx.fillRect(dir * 13, -40, 5, 8);
  ctx.restore();

  // Kite in the sky
  ctx.save();
  ctx.translate(kx, ky);
  ctx.rotate(dir * 0.25 + Math.sin(t * 3.2) * 0.16);

  if (kiteType === 'fish') {
    // Flying Koi fish kite!
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(26, 0);
    ctx.quadraticCurveTo(0, -18, -20, -14);
    ctx.lineTo(-32, -20); ctx.lineTo(-27, 0); ctx.lineTo(-32, 20); ctx.lineTo(-20, 14);
    ctx.quadraticCurveTo(0, 18, 26, 0);
    ctx.closePath();
    ctx.fillStyle = '#ff6b84'; ctx.fill();
    ctx.lineWidth = 2.6; ctx.strokeStyle = OUT; ctx.stroke();

    // Scales
    ctx.fillStyle = '#ffd23f';
    for (const sx of [-6, 6]) {
      ctx.beginPath(); ctx.arc(sx, 0, 5.5, -PI / 2, PI / 2); ctx.fill();
      ctx.lineWidth = 1.5; ctx.strokeStyle = OUT; ctx.stroke();
    }
    ell(ctx, 17, -4.5, 3.4, 3.4, '#fff', OUT, 1.4);
    ell(ctx, 17.5, -4.5, 1.6, 1.6, '#2a1a28');
  } else {
    // Diamond kite
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(0, -25); ctx.lineTo(18, 0); ctx.lineTo(0, 26); ctx.lineTo(-18, 0);
    ctx.closePath();
    ctx.fillStyle = '#4ea8e8'; ctx.fill();
    ctx.save();
    ctx.clip();
    ctx.fillStyle = '#ffd24a';
    ctx.beginPath(); ctx.moveTo(0, -25); ctx.lineTo(18, 0); ctx.lineTo(0, 0); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(0, 26); ctx.lineTo(-18, 0); ctx.lineTo(0, 0); ctx.closePath(); ctx.fill();
    ctx.restore();
    ctx.lineWidth = 2.6; ctx.strokeStyle = OUT; ctx.stroke();
  }

  // Waving tail ribbons
  ctx.strokeStyle = '#ff9f45'; ctx.lineWidth = 2.2; ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(-20, 14);
  for (let k = 1; k <= 6; k++) {
    const rx = -20 - k * 9 + Math.sin(t * 9 + k) * 6;
    const ry = 14 + k * 9 + Math.cos(t * 9 + k) * 5;
    ctx.lineTo(rx, ry);
  }
  ctx.stroke();

  // Little colored bows
  for (const bi of [2, 4, 6]) {
    const bx = -20 - bi * 9, by = 14 + bi * 9;
    ctx.fillStyle = bi % 2 === 0 ? '#ff5a8a' : '#5bd669';
    ctx.beginPath(); ctx.ellipse(bx, by, 3.5, 2.2, 0.4, 0, PI2); ctx.fill();
  }

  ctx.restore();
  ctx.restore();
}

// ---------------------------------------------------------------
//  4. BERJEMUR: KUCING BENAR-BENAR TIDURAN (REBAHAN DI HANDUK)
//     Sun on the LEFT -> Umbrella tilted LEFT, Shadow cast to RIGHT!
// ---------------------------------------------------------------
export function drawSunbathingCat(ctx: CanvasRenderingContext2D, x: number, y: number, t: number, pal: Pal, towelCol: string) {
  ctx.save();
  ctx.translate(x, y);

  // SUN FROM LEFT: Shadow falls to the RIGHT (+dx)
  ctx.globalAlpha = 0.22;
  ctx.fillStyle = '#3a2a10';
  ctx.beginPath(); ctx.ellipse(14, 8, 48, 18, 0.06, 0, PI2); ctx.fill();
  ctx.globalAlpha = 1;

  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';

  // 1. Striped Beach Towel
  ctx.beginPath(); ctx.roundRect(-42, -22, 84, 44, 7);
  ctx.fillStyle = towelCol; ctx.fill();
  ctx.save();
  ctx.beginPath(); ctx.roundRect(-42, -22, 84, 44, 7); ctx.clip();
  ctx.fillStyle = 'rgba(255,255,255,.7)';
  for (let k = -36; k <= 36; k += 14) ctx.fillRect(k, -24, 6, 48);
  ctx.restore();
  ctx.lineWidth = 2.6; ctx.strokeStyle = OUT; ctx.stroke();

  // Towel fringes
  ctx.strokeStyle = '#fff'; ctx.lineWidth = 2;
  for (const ty of [-16, -8, 0, 8, 16]) {
    ctx.beginPath(); ctx.moveTo(-42, ty); ctx.lineTo(-47, ty); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(42, ty); ctx.lineTo(47, ty); ctx.stroke();
  }

  // Soft pillow at head end (LEFT side, facing sun)
  ctx.beginPath(); ctx.roundRect(-38, -14, 18, 28, 6);
  ctx.fillStyle = '#fffdf0'; ctx.fill();
  ctx.lineWidth = 2; ctx.strokeStyle = OUT; ctx.stroke();
  ctx.strokeStyle = 'rgba(88,36,74,.22)';
  ctx.beginPath(); ctx.moveTo(-33, -8); ctx.lineTo(-33, 8); ctx.stroke();

  // 2. Beach Umbrella TILTED TO THE LEFT (Blocks sun from the left!)
  ctx.save();
  ctx.translate(-30, -22);
  ctx.rotate(-0.38); // Tilted strongly to the left!
  ctx.strokeStyle = OUT; ctx.lineWidth = 5.2; ctx.beginPath(); ctx.moveTo(0, 24); ctx.lineTo(0, -36); ctx.stroke();
  ctx.strokeStyle = '#ecd2a2'; ctx.lineWidth = 2.8; ctx.stroke();
  // Dome canopy
  ctx.beginPath();
  ctx.arc(0, -36, 32, PI, 0);
  ctx.closePath();
  ctx.fillStyle = '#ff6b84'; ctx.fill();
  ctx.save();
  ctx.beginPath(); ctx.arc(0, -36, 32, PI, 0); ctx.clip();
  ctx.fillStyle = '#ffd23f';
  ctx.beginPath(); ctx.moveTo(0, -36); ctx.lineTo(-14, -68); ctx.lineTo(14, -68); ctx.closePath(); ctx.fill();
  ctx.restore();
  ctx.lineWidth = 2.6; ctx.strokeStyle = OUT; ctx.stroke();
  ctx.restore();

  // 3. Cold tropical coconut drink with mini-umbrella on the right
  ctx.save();
  ctx.translate(32, 8);
  ell(ctx, 0, 0, 8, 8, '#774a22', OUT, 2);
  ell(ctx, 0, -4, 7, 3, '#f4e4c2');
  ctx.strokeStyle = '#ff4d6a'; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(0, -4); ctx.lineTo(5, -14); ctx.stroke();
  ctx.fillStyle = '#ffe14d';
  ctx.beginPath(); ctx.moveTo(2, -9); ctx.lineTo(9, -15); ctx.lineTo(6, -8); ctx.closePath(); ctx.fill();
  ctx.restore();

  // 4. REAL CAT MODEL LYING DOWN ON BACK (Kucing model asli berbaring tiduran santai di atas handuk!)
  // Using drawCat rotated 90 degrees (laying horizontal on the pillow and towel!)
  // Head on the left pillow (facing up/sun), paws resting naturally, tail resting on the right.
  const cat = makeCat(0, 0, { ...pal, shades: 'retro', tie: undefined });
  cat.t = t;
  cat.happy = 0;
  cat.exc = 0;
  cat.mv = 0;
  cat.speed = 0;
  cat.idleT = 1;
  cat.eyesOpen = false; // Wearing cool sunglasses while sunbathing!
  cat.fx = 0;
  cat.fy = 1;

  ctx.save();
  // Translate to center of towel
  ctx.translate(6, 0);
  // Rotate 90 degrees counter-clockwise so head lies towards pillow on the left (-X) and feet to the right (+X)
  ctx.rotate(-PI / 2);
  // Scale cat model
  drawCat(ctx, cat, 0.72);
  ctx.restore();  ctx.restore(); // world
}

// ---------------------------------------------------------------
//  5. 2X LAPANGAN VOLEI PANTAI, 2.4X BOLA BESI VOLI & 4 KUCING MELOMPAT
// ---------------------------------------------------------------
export interface VolleyballGame {
  courtX: number;
  courtY: number;
  ballX: number;
  ballY: number;
  ballZ: number;
  ballVz: number;
  ballSide: number; // -1 = left team, +1 = right team
  catL1: Cat;
  catL2: Cat;
  catR1: Cat;
  catR2: Cat;
}

export function makeVolleyballGame(x: number, y: number): VolleyballGame {
  // Cats positions relative to court (m.x = 0, m.y = 0 so drawCat doesn't double-translate!)
  const catL1 = makeCat(0, 0, CUSTOMER_PALS[0]);
  const catL2 = makeCat(0, 0, CUSTOMER_PALS[1]);
  const catR1 = makeCat(0, 0, CUSTOMER_PALS[2]);
  const catR2 = makeCat(0, 0, CUSTOMER_PALS[3]);

  catL1.happy = 0; catL1.exc = 0.8; catL1.eyesOpen = true;
  catL2.happy = 0; catL2.exc = 0.8; catL2.eyesOpen = true;
  catR1.happy = 0; catR1.exc = 0.8; catR1.eyesOpen = true;
  catR2.happy = 0; catR2.exc = 0.8; catR2.eyesOpen = true;

  return {
    courtX: x, courtY: y,
    ballX: x - 55, ballY: y - 10, ballZ: 45, ballVz: 220, ballSide: -1,
    catL1, catL2, catR1, catR2,
  };
}

export function updateVolleyball(vg: VolleyballGame, dt: number) {
  // Ball gravity & horizontal motion across the net
  const g = 440;
  vg.ballVz -= g * dt;
  vg.ballZ += vg.ballVz * dt;
  vg.ballX += vg.ballSide * -1 * 110 * dt;

  // Active cat spikes when ball reaches hitting zone!
  if (vg.ballZ < 42 && vg.ballVz < 0) {
    vg.ballVz = 230;
    vg.ballSide = -vg.ballSide;
    const spiker = vg.ballSide > 0 ? vg.catL1 : vg.catR1;
    spiker.hopY = 24;
    spiker.sqV = 7;
  }

  // Decay jump
  for (const c of [vg.catL1, vg.catL2, vg.catR1, vg.catR2]) {
    c.hopY = Math.max(0, c.hopY - 65 * dt);
  }
}

export function drawVolleyballCourt(ctx: CanvasRenderingContext2D, vg: VolleyballGame, t: number) {
  const { courtX: x, courtY: y } = vg;

  ctx.save();
  ctx.translate(x, y);

  // 1. 2X BIGGER SAND COURT (380px wide x 136px deep!)
  ctx.lineJoin = 'round';
  ctx.beginPath(); ctx.roundRect(-190, -68, 380, 136, 14);
  ctx.fillStyle = 'rgba(255,242,205,.4)'; ctx.fill();
  ctx.lineWidth = 3.6; ctx.strokeStyle = 'rgba(215,160,75,.85)';
  ctx.setLineDash([14, 10]); ctx.stroke(); ctx.setLineDash([]);

  // Court center dividing line
  ctx.beginPath(); ctx.moveTo(0, -68); ctx.lineTo(0, 68);
  ctx.strokeStyle = 'rgba(215,160,75,.6)'; ctx.lineWidth = 2.4; ctx.stroke();

  // 2. HIGH VOLLEYBALL NET (Across Y axis at X = 0)
  // High wooden support posts
  for (const py of [-74, 74]) {
    ctx.fillStyle = '#8a5a2b';
    ctx.fillRect(-4, py - 62, 8, 66);
    ctx.lineWidth = 2.4; ctx.strokeStyle = OUT; ctx.strokeRect(-4, py - 62, 8, 66);
    // Red flag on post top
    ctx.fillStyle = '#ff4d5e';
    ctx.beginPath(); ctx.moveTo(0, py - 62); ctx.lineTo(12, py - 56); ctx.lineTo(0, py - 50); ctx.closePath(); ctx.fill();
  }

  // White Volleyball Net Mesh (Taller!)
  const netH = 46;
  ctx.beginPath();
  ctx.moveTo(0, -74); ctx.lineTo(0, 74); ctx.lineTo(0, 74 - netH); ctx.lineTo(0, -74 - netH); ctx.closePath();
  ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 3; ctx.stroke();

  // Net grid pattern
  ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.lineWidth = 1.4;
  for (let gy = -74; gy <= 74; gy += 10) {
    ctx.beginPath(); ctx.moveTo(0, gy); ctx.lineTo(0, gy - netH); ctx.stroke();
  }
  // Bold Yellow Top Net Band
  ctx.strokeStyle = '#ffd23f'; ctx.lineWidth = 4.5;
  ctx.beginPath(); ctx.moveTo(0, -74 - netH); ctx.lineTo(0, 74 - netH); ctx.stroke();

  ctx.restore(); // court center

  // 3. 4 ACTIVE PLAYING CATS (PROPERLY TRANSLATED WITHOUT DOUBLE TRANSLATION BUG!)
  // Team Left: Front Spiker & Back Defender
  ctx.save();
  ctx.translate(x - 65, y + 12 - vg.catL1.hopY);
  vg.catL1.fx = 1; vg.catL1.side = 1;
  drawCat(ctx, vg.catL1, 0.82);
  ctx.restore();

  ctx.save();
  ctx.translate(x - 130, y - 18 - vg.catL2.hopY);
  vg.catL2.fx = 1; vg.catL2.side = 1;
  drawCat(ctx, vg.catL2, 0.78);
  ctx.restore();

  // Team Right: Front Spiker & Back Defender
  ctx.save();
  ctx.translate(x + 65, y + 12 - vg.catR1.hopY);
  vg.catR1.fx = -1; vg.catR1.side = -1;
  drawCat(ctx, vg.catR1, 0.82);
  ctx.restore();

  ctx.save();
  ctx.translate(x + 130, y - 18 - vg.catR2.hopY);
  vg.catR2.fx = -1; vg.catR2.side = -1;
  drawCat(ctx, vg.catR2, 0.78);
  ctx.restore();

  // 4. 2.4X BIGGER BEACH VOLLEYBALL BALL
  // Radius was 9.5 -> 9.5 * 2.4 = ~23px radius!
  const BR = 23;
  ctx.save();
  // Ball shadow on court (grows/shrinks with height)
  ctx.globalAlpha = Math.max(0.12, 0.38 - vg.ballZ * 0.002);
  ctx.fillStyle = '#3a2a10';
  ctx.beginPath(); ctx.ellipse(vg.ballX + 10, vg.ballY + 4, BR * 0.9 - vg.ballZ * 0.04, BR * 0.4 - vg.ballZ * 0.02, 0, 0, PI2); ctx.fill();
  ctx.globalAlpha = 1;

  // Ball in air (spins as it flies!)
  ctx.translate(vg.ballX, vg.ballY - vg.ballZ);
  ctx.rotate(t * 6);

  ctx.beginPath(); ctx.arc(0, 0, BR, 0, PI2);
  ctx.fillStyle = '#ffffff'; ctx.fill();
  ctx.lineWidth = 3.6; ctx.strokeStyle = OUT; ctx.stroke();

  // Colorful tri-panel beach ball (Yellow, Sky Blue, White)
  ctx.save();
  ctx.beginPath(); ctx.arc(0, 0, BR, 0, PI2); ctx.clip();
  // Yellow panel
  ctx.fillStyle = '#ffd23f';
  ctx.beginPath(); ctx.arc(0, 0, BR, -0.7, 0.7); ctx.lineTo(0, 0); ctx.closePath(); ctx.fill();
  // Blue panel
  ctx.fillStyle = '#3eb5f0';
  ctx.beginPath(); ctx.arc(0, 0, BR, 1.4, 2.8); ctx.lineTo(0, 0); ctx.closePath(); ctx.fill();
  // Center badge
  ctx.beginPath(); ctx.arc(0, 0, 5, 0, PI2); ctx.fillStyle = '#ffffff'; ctx.fill();
  ctx.lineWidth = 2; ctx.strokeStyle = OUT; ctx.stroke();
  ctx.restore();

  ctx.restore();
}

// ---------------------------------------------------------------
//  6. PLAYGROUND ROAMING KITTENS & PLAYFUL CATS
// ---------------------------------------------------------------
export interface PlaygroundCat {
  x: number;
  y: number;
  pal: Pal;
  size: number;
  build: Partial<import('./cat').CatCfg> | null;
  mode: 'tag' | 'ball' | 'chase';
  t: number;
  seed: number;
}

export function makePlaygroundCats(): PlaygroundCat[] {
  return [
    // Two playful kittens playing tag
    { x: 700, y: 1350, pal: CUSTOMER_PALS[0], size: 0.52, build: { head: 1.5, legs: 0.7 }, mode: 'tag', t: 0, seed: 1 },
    { x: 740, y: 1360, pal: CUSTOMER_PALS[1], size: 0.52, build: { head: 1.5, legs: 0.7 }, mode: 'tag', t: 0, seed: 2 },
    // Kid cat playing with beach ball
    { x: 1020, y: 1420, pal: CUSTOMER_PALS[4], size: 0.74, build: { head: 1.32, legs: 0.9 }, mode: 'ball', t: 0, seed: 3 },
    // Playful cat chasing a sand crab
    { x: 1780, y: 1420, pal: CUSTOMER_PALS[3], size: 0.85, build: null, mode: 'chase', t: 0, seed: 4 },
  ];
}

export function updatePlaygroundCats(cats: PlaygroundCat[], dt: number) {
  for (const pc of cats) {
    pc.t += dt;
    if (pc.mode === 'tag') {
      // Run around in circular chase loop
      const a = pc.t * 1.6 + pc.seed * 3;
      pc.x += Math.cos(a) * 45 * dt;
      pc.y += Math.sin(a) * 30 * dt;
    } else if (pc.mode === 'ball') {
      // Dribbling back and forth
      pc.x += Math.sin(pc.t * 2) * 35 * dt;
    } else if (pc.mode === 'chase') {
      pc.x += Math.cos(pc.t * 1.8) * 40 * dt;
    }
  }
}

export function drawPlaygroundCatItem(ctx: CanvasRenderingContext2D, pc: PlaygroundCat, t: number) {
  const cat = makeCat(0, 0, pc.pal);
  cat.t = t;
  cat.size = pc.size;
  cat.build = pc.build;
  cat.mv = 1;
  cat.speed = 170;
  cat.r = 0.5; // Natural bouncy run animation!
  cat.phase = pc.t * 12; // Natural step cycle!
  cat.happy = 0;       // Open eyes!
  cat.eyesOpen = true; // Wide alert cute eyes!
  cat.exc = 0.8;
  const dir = Math.sin(pc.t * 2) >= 0 ? 1 : -1;
  cat.fx = dir;
  cat.side = dir;

  ctx.save();
  ctx.translate(pc.x, pc.y);
  drawCat(ctx, cat, 0.78);

  // If playing with small beach ball
  if (pc.mode === 'ball') {
    const bx = 16 * cat.fx, by = -4;
    ell(ctx, bx, by + 6, 8, 3, 'rgba(50,30,10,.25)');
    ctx.beginPath(); ctx.arc(bx, by, 8, 0, PI2);
    ctx.fillStyle = '#ff6b84'; ctx.fill();
    ctx.lineWidth = 1.8; ctx.strokeStyle = OUT; ctx.stroke();
    ctx.beginPath(); ctx.arc(bx, by, 8, -0.6, 0.6); ctx.lineTo(bx, by); ctx.closePath();
    ctx.fillStyle = '#ffd24a'; ctx.fill();
  }
  ctx.restore();
}
